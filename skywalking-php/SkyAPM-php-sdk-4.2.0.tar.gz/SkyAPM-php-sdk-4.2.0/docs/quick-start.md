# Get started quickly with docker

See [Dockerfile](../docker/Dockerfile)

